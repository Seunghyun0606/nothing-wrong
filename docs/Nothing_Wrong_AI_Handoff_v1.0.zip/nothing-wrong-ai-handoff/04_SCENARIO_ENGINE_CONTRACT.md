# NOTHING WRONG — Scenario Engine / Data / Review Contract

## 목적

개발 AI가 `03_PLAYABLE_TICKETS.md`의 각 Ticket을 독립적이고 재현 가능한 콘텐츠로 구현하기 위한 최소 계약. **지금 당장 코딩하라는 지시가 아니라 구현 시 준수할 명세**다.

## 시스템 경계

```text
Game Shell (Dashboard, Inbox, Career, Reports)
  ├── Ticket/Requirement
  ├── QA Workspace (Account, Locale, Viewport, Source/Target, Trace)
  │    └── Fake Product(s): Shoply / PeopleCore / Triply / Procura / etc.
  ├── Scenario Runtime (Fixtures + Conditions + Mutations)
  ├── Evidence / Case Notes
  ├── Report / Deterministic Reviewer
  └── Campaign Progression / Narrative Clues
```

- 별도의 실제 외부 사이트/운영 ERP/API 호출 없음. UI 안에서 Fake Product가 실제로 동작하는 React 컴포넌트.
- 정상 제품 Rule이 우선. `Scenario Mutation`은 기술 오류만 발생시키고 **범죄/정책 정황의 정합 데이터는 Base Fixture**에 보관.
- 시나리오 간 Entity, 사건 시점, 거래, 사진 식별자는 **Canonical Dataset**에서 공유. 다른 Ticket에서 같은 인물의 생년/이름·이벤트 시각이 바뀌면 안 됨.
- 같은 Seed/Action Log를 Replay하면 같은 상태/증거/Review가 나와야 함. 런타임 LLM 판정 없음.
- 사용자가 실제 원본 ERP 자료를 넣도록 요구하지 않는다. 모든 데이터는 픽션/테스트 데이터다.

## 디렉터리 제안

```text
src/
  game/domain/{ticket,scenario,evidence,report,narrative}.ts
  game/engine/{scenarioRuntime,mutationResolver,reviewEngine}.ts
  game/data/{entityBible,normalRules,fixtureFactory}.ts
  products/{shoply,peoplecore,triply,procura,...}/
  scenarios/campaign/NW-001.json ... NW-030.json
  assets/narrative/{images,metadata}.json
  ui/{gameShell,fakeBrowser,qaWorkspace,reportBuilder,caseNotes}/
  persistence/
tests/{unit,scenario,e2e,narrative}/
```

## 최소 TS 타입 예시

```ts
export type TicketOutcome =
  | 'BUG'
  | 'NO_BUG'
  | 'DOC_GAP'
  | 'DATA_INTEGRITY'
  | 'INCONCLUSIVE';

export type EvidenceType =
  | 'SCREENSHOT'
  | 'SOURCE_TARGET_COMPARE'
  | 'TRACE'
  | 'RECORD_SNAPSHOT'
  | 'IMAGE'
  | 'IMAGE_METADATA'
  | 'DOCUMENT_FRAGMENT'
  | 'AUDIT_METADATA'
  | 'TIMELINE';

export interface Scenario {
  id: string;                    // NW-001
  act: number;
  ticket: TicketDefinition;
  productIds: string[];
  fixtureId: string;
  initialContext: Record<string, unknown>;
  mutations: MutationDefinition[];
  expectedFindings: FindingDefinition[];
  evidenceRules: EvidenceRule[];
  narrativeClues: NarrativeClueDefinition[];
  review: ReviewConfig;
  unlocks: string[];
}

export interface TicketDefinition {
  title: string;
  senderEntityId: string;
  briefing: string;
  requirements: Array<{id: string; text: string}>;
  inScope: string[];
  permittedDataViews: string[];
}

export interface MutationDefinition {
  id: string;
  type: 'WRONG_STYLE' | 'WRONG_NUMBER' | 'HIDE_ELEMENT'
    | 'WRONG_STATE' | 'WRONG_ACTION' | 'WRONG_CALCULATION'
    | 'CROSS_SCREEN_MISMATCH' | 'WRONG_METADATA';
  target: string;
  conditions: Array<{field: string; op: 'EQ'|'NEQ'|'IN'|'GTE'|'LTE'; value: unknown}>;
  payload: Record<string, unknown>;
}

export interface FindingDefinition {
  id: string;
  outcome: TicketOutcome;
  target?: string;
  severity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  expected: string;
  actual: string;
  reproductionConditions: Record<string, unknown>;
  caveats?: string[];
}

export interface EvidenceRule {
  findingId: string;
  allowedTypes: EvidenceType[];
  requiredContextKeys: string[];
  minimumCount: number;
}

export interface NarrativeClueDefinition {
  id: string;                 // C004, IMG001 etc.
  source: EvidenceType | 'DIALOGUE';
  entityIds: string[];
  exposure: 'MANDATORY' | 'OPTIONAL' | 'MISSABLE';
  acquisitionCondition: string;
  initialMeaning: string;
  reinterpretAfter?: string[];
}

export interface ReviewConfig {
  expectedOutcomes: TicketOutcome[];
  scoringWeights: {detection: number; reproduction: number;
    evidence: number; classification: number};
  reviewOverride?: {
    actorEntityId: string;
    afterReport: 'ACCEPTED_EXCEPTION' | 'ESCALATED' | 'NO_ACTION';
    message: string;
  };
}

export interface NarrativeState {
  knownEntityIds: string[];
  foundClueIds: string[];
  hypotheses: Record<string, 'SUPPORTED'|'REJECTED'|'UNKNOWN'>;
  caseNotesUnlocked: boolean;
  relationshipEdges: Array<{sourceId: string; targetId: string; evidenceIds: string[]}>;
}
```

> 기존 프로젝트 엔진에 타입/명명 규칙이 이미 있다면 그것을 우선한다. 원칙(데이터·도메인 분리)을 보존하면서 호환하라. 브랜드명 접두어를 타입에 무조건 추가하지 말 것.

## 샘플 시나리오 1 — NW-005 (UI 오류 + Narrative Clue)

```json
{
  "id": "NW-005",
  "act": 1,
  "productIds": ["peoplecore", "payflow"],
  "fixtureId": "PAYROLL_SAMPLE_COMMUNITY_01",
  "ticket": {
    "title": "Payroll deduction display mismatch",
    "senderEntityId": "P-MINA",
    "briefing": "급여 요약의 공제 항목 및 실수령액 정합성을 검증하세요.",
    "requirements": [
      {"id":"R1", "text":"급여 상세 공제 항목은 요약에 모두 표시되어야 합니다."},
      {"id":"R2", "text":"실수령액은 총액에서 모든 공제액을 뺀 금액입니다."}
    ],
    "inScope": ["payroll.summary", "payroll.detail"],
    "permittedDataViews": ["masked_sample_payroll"]
  },
  "initialContext": {"account":"SAMPLE_BASIC", "viewport":"DESKTOP"},
  "mutations": [
    {"id":"M-NW005-01", "type":"HIDE_ELEMENT", "target":"payroll.summary.deduction.community",
     "conditions": [{"field":"account", "op":"EQ", "value":"SAMPLE_BASIC"}],
     "payload":{"hidden":true}}
  ],
  "expectedFindings": [{
    "id":"F-NW005-01", "outcome":"BUG", "target":"payroll.summary.deduction.community",
    "severity":"LOW", "expected":"Community Contribution 260이 summary에 표시된다.",
    "actual":"상세에 존재하지만 summary 행에서 누락된다.",
    "reproductionConditions":{"account":"SAMPLE_BASIC"}
  }],
  "evidenceRules": [{
    "findingId":"F-NW005-01", "allowedTypes":["SCREENSHOT","RECORD_SNAPSHOT"],
    "requiredContextKeys":["summary","detail","account"], "minimumCount":1
  }],
  "narrativeClues": [{
    "id":"C003", "source":"RECORD_SNAPSHOT", "entityIds":["O-FOUNDATION"],
    "exposure":"MANDATORY", "acquisitionCondition":"open(payroll.detail)",
    "initialMeaning":"사내 복지·기부 관련 공제 항목",
    "reinterpretAfter":["NW-022"]
  }],
  "review":{"expectedOutcomes":["BUG"],
    "scoringWeights":{"detection":40,"reproduction":25,"evidence":20,"classification":15}},
  "unlocks":["ACT1_CORE_COMPLETE"]
}
```

Normal Fixture 계산: `gross=5200; tax=410; insurance=190; community=260; net=4340`. 원본의 공제 `260`은 사라진 돈이라고 확정하지 않는다. `HIDE_ELEMENT` Mutation만 제거하면 UI는 정상으로 돌아와야 한다.

## 샘플 시나리오 2 — NW-020 (No Bug + 의미 있는 사실)

```json
{
  "id": "NW-020",
  "act": 5,
  "productIds": ["procura"],
  "fixtureId": "VENDOR_CLUSTER_01",
  "ticket": {
    "title": "Duplicate vendor candidate review",
    "senderEntityId": "P-MINA",
    "briefing": "중복 후보가 오탐인지 원본 속성을 비교해 검증하세요.",
    "requirements":[{"id":"R1", "text":"허용 임계값을 넘는 후보군은 관계 검토 대상으로 표시됩니다."}],
    "inScope":["vendor.matching", "vendor.candidate.detail"],
    "permittedDataViews":["masked_vendor_attributes", "approval_summary"]
  },
  "initialContext":{"matchGroupId":"V-GROUP-17"},
  "mutations":[],
  "expectedFindings":[{
    "id":"F-NW020-01", "outcome":"NO_BUG",
    "expected":"관계 검토 대상으로 표시", "actual":"관계 검토 대상으로 표시됨",
    "reproductionConditions":{"matchGroupId":"V-GROUP-17"},
    "caveats":["동일 범죄조직 또는 동일 법인이라고 단정할 수 없음"]
  }],
  "evidenceRules":[{
    "findingId":"F-NW020-01", "allowedTypes":["RECORD_SNAPSHOT"],
    "requiredContextKeys":["matchingSignals","threshold","candidateList"], "minimumCount":1
  }],
  "narrativeClues":[{
    "id":"C020", "source":"RECORD_SNAPSHOT", "entityIds":["P-DANIEL","O-BF-CONSULTING"],
    "exposure":"MANDATORY", "acquisitionCondition":"open(vendor.approvalSummary)",
    "initialMeaning":"과거 검토자가 거래를 반려함",
    "reinterpretAfter":["NW-027"]
  }],
  "review":{"expectedOutcomes":["NO_BUG"],
    "scoringWeights":{"detection":40,"reproduction":25,"evidence":20,"classification":15}},
  "unlocks":[]
}
```

## QA 리포트 판정 규칙

- 기본 점수: `Detection 40 + Reproduction 25 + Evidence 20 + Classification 15`.
- 예외/업무 결정은 **Reviewer Result**와 **Client Disposition**을 별개 필드로 저장한다. 예: QA Valid Data Issue이지만 Client Accepted Risk.
- `NO_BUG`는 정상 동작임을 입증한 비교/Requirement 인용이 필요하다. 아무것도 보지 않고 '문제없음'을 찍으면 낮은 점수.
- `DOC_GAP`는 구현이 정상이라도 요구사항에서 누락된 조건을 보고할 수 있게 해야 한다. NW-023에서 플레이어의 버그 오판을 일방적으로 'INVALID'로 모욕하지 말 것.
- `DATA_INTEGRITY`는 권한 있는 운영 주체가 사실관계 확인/정정할 수 있다. QA가 인적 사고·살인을 법적으로 확정하는 기능 없음.
- 시나리오에서 발견된 `Clue`는 Report 채점과 독립하며 Story 게이트/Case Notes에서 쓰인다.

## 데이터 접근 및 Case Notes 정책

- `TestDataScope`: `SYNTHETIC`, `MASKED_LEGACY`, `AUTHORIZED_RECORD_FRAGMENT`, `UNEXPECTED_SENSITIVE_EXPOSURE` 중 하나.
- `UNEXPECTED_SENSITIVE_EXPOSURE`를 Story에 활용하면 **보안/개인정보 QA 이슈**도 생성해야 하며 플레이어가 무단 복제·외부 공개하는 선택을 강제하지 않는다.
- Case Notes에는 Entity ID, 출처/스냅샷 버전, 그 시점에 플레이어가 알 수 있는 정보만 저장. 캐릭터의 추측을 사실 데이터로 덮어쓰지 않는다.
- 이미지 메타데이터의 `captureAt`과 `uploadedAt`을 분리. EXIF가 반드시 참이라는 UI 연출 금지.
- evidenceId/sourceTicketId/recordId/fixtureVersion/snapshotHash를 제공해 재현 가능한 QA 증거 구성.

## 엔진 테스트 항목

1. Normal fixture에서 Mutation OFF 시 모든 정상 Product Rule 통과.
2. 각 Mutation의 **positive trigger**와 **negative trigger** 검증.
3. 같은 Story Entity의 ID·날짜·명칭은 전체 캠페인에서 일치.
4. Story Clue는 업무 범위 내 행동만으로 획득 가능.
5. Required clue는 미획득 시 다른 합법적 Ticket/요약 힌트로 재접근 가능.
6. No-Bug도 진행과 점수 획득 가능.
7. 사용자 조작 없이 시간을 경과시키는 강제 마이크로타이밍 퍼즐 금지(시각 단서는 타임라인 비교).
8. Fresh Start/Save/Load/Replay에서 동일 Evidence/Review/Progression 재현.
9. 이미지를 제외한 시나리오에서 자산 누락이 생겨도 Game Shell 에러로 끝나지 않음.
10. Review/Client override가 독립적으로 기록되며 QA 결과를 임의 변조하지 않음.
