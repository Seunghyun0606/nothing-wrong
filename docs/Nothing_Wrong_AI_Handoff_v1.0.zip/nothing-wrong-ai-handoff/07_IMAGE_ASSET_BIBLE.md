# NOTHING WRONG — Narrative Image & Evidence Asset Bible

## 목적

웹/SaaS 화면 중심의 Nothing Wrong에서 반복 등장하는 사진은 서사의 **관계·장소·시간 단서**이자 정상적인 이미지 마이그레이션 QA 대상이다. 개발 또는 이미지 제작 AI가 사진별 얼굴·복장·상징·공간을 일관되게 생성할 수 있도록 정의한다.

이미지 자체는 **이 문서에 포함되지 않음**. AI 이미지 제작 단계에서 별도 생성해야 하며, 사용자가 이미지 생성을 요청한 상태가 아니다.

## 인물 시각 ID (외형 세부는 미확정)

| Character ID | 이름 | 반복 시 일관성 조건 | 설정된 역할 |
|---|---|---|---|
| `P-DANIEL` | Daniel Park | 동일 얼굴·피부톤·헤어 실루엣·연령대 변화(2019→2021) | Internal Control Analyst |
| `P-GRACE` | Grace Yoon | 동일 얼굴, 2019/2021의 직장 스타일 차이 허용 | Horizon PM |
| `P-SAMUEL` | Samuel Kwon | 동일 얼굴·체형·재단 행사 배지 | Foundation Director |
| `P-CEO` | Horizon CEO | 외형 미확정, IMG001/004 등장 시 동일 | Horizon 경영진 |
| `P-SECURITY` | Foundation Security Director | IMG007에서 식별 가능, 외형 미확정 | 사고 현장 관계자 |

**생성 순서**: Character Face Sheet → Foundation Badge/Logo Sheet → Horizon Ridge Environment Sheet → 실제 7장 사진 → CMS 썸네일/크롭/회전 등 결함 버전. 주연 얼굴을 사진마다 독립적으로 랜덤 생성하면 **관계 추리 시스템이 붕괴**한다.

## 사진·시각 증거 목록

| Asset | 촬영 콘셉트 / 인물 | 플레이가 먼저 요구하는 작업 | 서사적 재해석 | 관련 Ticket |
|---|---|---|---|---|
| `IMG001` | **Horizon Leadership Awards 2021**. Grace·Samuel·Daniel·임원. 공식 수상 행사, 무난한 회사 행사사진 | 크롭된 썸네일에서 오른쪽 인물 얼굴이 잘림 | 세 사람이 예전부터 서로 아는 관계였을 가능성 | NW-004 |
| `IMG002` | **Horizon Ridge Leadership Retreat**. Grace·직원·시설 배경, Foundation 상징 일부 | Album metadata category 수정 | 리트릿/날짜/재단 상징과 사고 장소 연결 | NW-014 |
| `IMG003` | **Foundation Gala 2019**. Samuel·Grace·Daniel | Foundation Portal 갤러리·반응형 이미지 테스트 | 재단과 기업인/직원의 오래된 인적 교류 | NW-022 |
| `IMG004` | **Leadership Dinner**. Samuel·Horizon CEO, 같은 배지/로고 | Tablet 사진 레이아웃 테스트 | 재단과 최고 경영진의 친밀한 접점 | NW-022 |
| `IMG005` | **Foundation Family Retreat**. Grace 포함 | 사진 확대/metadata 보기 | 공식 경력보다 오랜 재단 관계 암시 | NW-022 |
| `IMG006` | **International Opportunity Cohort**. 집단 사진, 일부 얼굴은 이후 다른 프로필에 재등장 | 직원/프로필 이미지 이관 비교 | 신원 중복/관리자 대리 관리 가능성 | NW-026 |
| `IMG007` | **Horizon Ridge 현장 사진**. 사고 전 Daniel·Grace·Samuel·보안책임자 | Orientation/Thumbnail 오류 비교 | Daniel의 행사 참석과 관계자 접점 | NW-028 |

## Canonical metadata fields

```ts
interface ImageNarrativeAsset {
  assetId: string;
  canonicalPeople: string[];      // person IDs
  locationId: string | null;
  capturedAtLocal: string | null;  // 시각 자체는 변조 가능
  capturedTimezone: string | null;
  uploadedAt: string | null;       // 촬영시각과 별개
  uploadedByEntityId: string | null;
  visibleSymbols: string[];
  narrativeMeaning: string[];
  linkedTicketIds: string[];
  cropVariants: Array<{id: string; focalPoint: string; defect: string}>;
  reliability: 'VERIFIED' | 'UNVERIFIED' | 'CORROBORATED';
}
```

`image metadata`는 검증 전까지 **UNVERIFIED**로 유지할 수 있다. 사진에서 서로 같은 사람처럼 보이는 것과 그 사람의 **신원 검증**은 다른 문제다. IMG006은 다른 자료(직원 참조/출입/프로필 과거 이력 등)와 조합했을 때만 강한 단서가 된다.

## 이미지 QA 메커니즘

1. **Source vs Target Crop**: 원본에는 4명이 있지만 Preview에는 3명만 보이는지.
2. **Orientation**: EXIF 미적용으로 90도 회전; 복구한 뒤에도 새로운 Narrative details가 보이는지.
3. **Gallery Category**: 사진의 행사 타입과 이관된 앨범 분류가 다름.
4. **Profile Identity**: 별명/Employee ID가 바뀌었어도 여러 사진의 인물이 같아 보임; 추가 데이터로 교차 검증.
5. **Time/Place**: 사진 metadata, 행사 배너, 출장 날짜, 근태 기록 비교.

## 시각적 연출 원칙

- 사진을 보는 즉시 `CRITICAL CLUE!` 알림 금지. 일반 QA Attachment처럼 보여준다.
- 관객에게 **누가 누구인지** 처음부터 캡션으로 알려주지 않는다. 사내 인물프로필을 나중에 접했을 때 스스로 알아차리도록 한다.
- 종교·사이비 심벌은 초기부터 과도하게 위협적이지 않아야 함. 사회공헌재단의 무난한 로고로 시작.
- 살인/약물/착취는 충격적인 피해 사진이 아니라 기록·사진의 **불편한 불일치**로 표현.
- 사진 한 장이 사건의 확정 판결이 되지 않는다. 반드시 문서/출장/입출입 등 추가 증거와 결합.
- Narrative-critical 이미지 7장은 보조 텍스트와 메타데이터 경로도 제공해 로딩 실패/접근성 이슈가 메인 플레이를 막지 않도록 한다.

## 아트 QA 체크리스트

- [ ] 동일 인물 얼굴이 모든 사진에서 추적 가능한 수준으로 유지되는가?
- [ ] 배지/로고의 형태가 동일한가? 다른 브랜드 로고와 혼동되지 않는가?
- [ ] 2019·2021 사진의 시대감과 촬영 장소가 자연스러운가?
- [ ] Narrative Canon상 없는 인물이 사진에 추가되어 진실을 바꾸지 않는가?
- [ ] Source Crop/Target Crop 재현을 위한 충분한 해상도와 Composition인가?
- [ ] EXIF `capturedAt`, CMS `uploadedAt`, Ticket Date가 각각 별도로 관리되는가?
- [ ] 배경의 우연한 AI 생성 텍스트가 스토리의 False Clue가 되지 않는가?
- [ ] 이미지 자체에 개인정보/실제 인물·실제 기관 연상 요소가 불필요하게 들어 있지 않은가?
