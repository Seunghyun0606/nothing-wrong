# NOTHING WRONG — 메인 캠페인 시놉시스

- 문서 버전: 1.0
- 기준: `Main Campaign Scenario v0.5` + `Playable Content v0.1`
- 장르: 오피스 QA 시뮬레이션 → 기업범죄 미스터리 → 제도적 스릴러
- 주제문: **시스템이 의도한 대로 정확하게 작동한다면, 그 의도 자체가 잘못되었을 때도 '정상'인가?**

## 로그라인

거대 기업집단 Horizon Group의 전사 시스템 통합 프로젝트에 파견된 외주 QA 직원. 평범한 웹 기능과 데이터 이관을 검증하던 그는 여러 서비스에서 반복되는 **10월 17일**의 불일치를 발견한다. 서로 다른 직원·거래·출장·보험 기록이 하나의 인물 **Daniel Park**로 수렴하고, 오래된 시설 사고의 흔적 뒤에서 `Horizon Foundation`이라는 폐쇄적 조직과 그룹의 부패한 운영구조가 드러난다. 그러나 가장 큰 반전은 그것을 실행한 프로그램들이 고장 난 것이 아니라 **요구사항대로 작동해 왔다**는 사실이다.

## 배경 — ONE HORIZON

플레이어는 외부 QA 업체 `Northstar Quality Services` 소속이다. 고객사 `Horizon Group`은 계열사 HR/쇼핑/결제/출장/구매/의료·복지/물류 데이터의 기준 ID와 통합 인터페이스를 묶는 `ONE HORIZON — Digital Integration Program`을 추진한다.

플레이어가 접하는 제품:
- **Shoply**: 임직원 구매·전자상거래
- **PeopleCore**: 인사·직원 상태
- **PayFlow**: 급여/비용 정산의 제한적 QA 뷰
- **Triply**: 출장/예약/경비
- **Horizon ID**: 직원 계정 및 글로벌 인물 매핑
- **Corporate CMS / Foundation Portal**: 행사/홍보 이미지
- **Procura**: 구매·벤더 마스터
- **CareBridge / Insurance**: 의료 비용·복리후생 정산의 제한적 데이터
- **RouteOne**: 물류 및 수령인
- **Compliance / Archive / Organization Master**: 사고 통계, 이전 문서, 조직/관계 매핑

업무 환경은 운영 DB 자유 조회가 아니라 QA/UAT 스냅샷과 Ticket에 승인된 최소 레코드·메타데이터만 노출한다. 민감 데이터는 원칙적으로 마스킹되어야 한다. **우연히 노출된 식별·의료 정보는 별도 데이터보호 결함**이기도 하다.

## 시작 — 평범한 일, 평범한 버그 (ACT 1 / NW-001~005)

직속 QA Lead **Mina Seo**는 재현 조건, Expected/Actual, Evidence, Severity를 차근차근 가르친다. 플레이어는 결제 버튼 색, 장바구니 합계, 직원 복지 등급 동기화, 행사 사진 썸네일 잘림, 급여 공제 항목 누락 같은 기능을 테스트한다.

기획상 첫 사진에는 프로그램 관리자 **Grace Yoon**, Foundation 이사 **Samuel Kwon**, 직원 **Daniel Park**가 함께 찍혀 있지만 이름표가 표시되지 않는다. 당시 QA 목적은 잘린 썸네일을 재현하는 것뿐이다. `Community Tier`, `Community Contribution` 같은 용어도 단순한 사내 제도처럼 보인다. **단서를 발견했다는 별도 알림은 뜨지 않는다.**

## 이상한 하루 — October 17 (ACT 2 / NW-006~009)

플레이어는 우수한 데이터 검증 성과로 Legacy Migration 티켓을 더 맡는다. 쇼핑 주문 기록의 특정 날짜가 누락되고, Triply에는 `HRDG-01`행 **38명 출발·돌아오는 예약 0건**, PeopleCore에는 같은 날 **교육휴가 38명**, 다음 날 **퇴사 12명**이 나타난다. 계속 등장하는 직원 ID는 `E-18419`, Daniel Park다.

퇴사일이 10월 16일인 Daniel에게 그 후 여러 달 급여성 거래가 존재한다. 플레이어는 상식적인 통합 QA 결함으로 Report하지만 고객사 승인 예외(`KNOWN ISSUE / LEGACY EXCEPTION`)로 처리된다. 당시 플레이어의 가장 합리적인 가설은 **공통 Migration Batch 오류**다.

## 원본이 이미 달랐다 (ACT 3 / NW-010~014)

`Global Identity Matching` 업무에서 PeopleCore·Triply·CareBridge·PayFlow의 서로 다른 레거시 ID가 `P-004217 — Daniel Park`로 통합된다. 시스템 통합 이전에는 각 부서와 감사 담당자가 **각자 다른 ID로 자신들의 기록만** 다뤄야 했다.

Integration Developer **Alex Han**은 각 시스템의 마이그레이션 실행 시점이 달랐음을 보여준다. 이것들은 동일한 Batch에서 파손될 수 없다. 제한된 Audit Metadata를 보면 사건 직후 여러 부서가 각각 `DATA_CORRECTION`을 수행했다. 한 사람이 모든 기록을 삭제한 정황이 아니라 **서로 다른 정상적인 행정 절차가 같은 사건의 관계를 끊은 듯한 패턴**이다.

출장의 `HRDG-01`은 실제로 `Horizon Ridge — Leadership & Wellness Center`이며, 행사 사진에는 Foundation의 기호와 Grace가 보인다. 플레이어는 아직 범죄보다 **원천 데이터 정합성 문제**를 먼저 의심한다.

## Zero Incident — 죽은 직원의 기록 (ACT 4 / NW-015~019)

의료비/혜택 지급 검증에서 Daniel의 글로벌 인물 ID와 `DB-01`이 다시 나타난다. 긴급 구매 기록은 Horizon Ridge에 집중된다. 그러나 월별 사고 Dashboard는 `Major Incidents: 0`; 상세 참조에는 `INC-1017 / DUPLICATE / Original Unavailable`이 남아 있다. 이후 보험 코드 매핑 QA에서 `DB-01 = Death Benefit`임이 드러난다.

플레이어는 HR `Voluntary Resignation`, 출장 `No Return`, 의료 `Emergency Record`, 보험 `Death Benefit`을 비교하여 **Daniel이 과거 사고에서 사망했다**는 사실을 알아낸다. 이 시점에 `Case Notes / Evidence Board`가 열린다.

플레이어가 제출한 Cross-System Data Integrity Report에는 **Grace Yoon**이 직접 `Historical Exception / No Action Required`를 적용한다. 보험 첨부의 공식 요약 문서에는 당시 Horizon Ridge에서 사망 1명·부상 여러 명이 발생했고 사고로 분류되었다는 정보가 있다. **공권력과 응급기관은 실제 개입했다.** 미스터리는 '죽음을 숨겼다'가 아니라 **사고 당시 Daniel의 고용/업무상 지위가 왜 사후적으로 바뀌었는가, 왜 사고 기록의 관련성이 제거되었는가**다.

## The Foundation — 정상 규칙이 만든 비정상 (ACT 5 / NW-020~026)

Procura의 글로벌 벤더 매칭을 검증하면 서로 다른 업체처럼 보였던 `Bright Future Consulting`, `BF Consulting`, `New Path Logistics`, `Horizon Living` 등이 등록대리인·주소군·연락처 등에서 반복적으로 겹친다. 이 거래를 과거에 **Daniel이 REJECT**했다는 승인 이력이 있다.

특정 업체의 예외적인 할인/우선 배정은 프로그램 결함이 아니라 `COMMUNITY_PARTNER_OVERRIDE`라는 **승인된 룰**이었다. CMS/재단 웹페이지 사진을 통해 Samuel·Grace·경영진의 오래된 관계가 재해석된다. 사진은 교류의 정황을 제공할 뿐 공모를 증명하지 않는다.

이어 인사 승진 테스트에서 성과와 근속을 충족한 직원이 탈락한다. 플레이어가 Bug로 보고하면 뒤늦게 `Community Alignment >= 70`이라는 정식 시스템 룰이 제시된다. 점수는 Foundation 행사·기부·리트릿 등과 연결되고 승진·주거·전근·복지에 영향을 준다. **불일치는 구현 오류가 아니라 공개 요구사항과 실제 승인 룰 사이의 간극**이었다.

다른 Ticket은 정상 의료 사용량에 반영되지 않는 관리 의료재고의 시설 간 이동, `Horizon Opportunity Program` 참가자의 장기간 미로그인·관리자 통제 연락처·귀환 정보 누락·이름/사진 불일치 등을 보여준다. 플레이어는 **약품 유출과 노동착취/인신매매를 의심할 정황**을 얻지만 이를 자동으로 기정사실화하지 않는다.

## Daniel's Last Case — 마지막 검증 (ACT 6 / NW-027~030)

Document Archive Migration의 접근권한 이슈를 재현하면서 Daniel이 사망 전 `Irregular Vendor and Foundation Transactions`라는 내부통제 Case를 작성했고 **사망 다음 날 그 Case가 종료**되었음을 확인한다. 사진 미리보기 회전 버그로 본 첨부 사진에는 사건 직전 Daniel·Grace·Samuel·Foundation 보안책임자가 같은 장소에 있다. 타임존 보정 QA를 거친 뒤에도 일부 출입·의료·차량 기록 간 동선 불일치가 남는다.

플레이어는 Daniel이 **사고사인지, 의도적으로 표적이 되었는지 확정할 수 없다**. Mina는 과거 유사한 Legacy 문제를 건드린 QA가 프로젝트에서 배제된 전례 때문에 플레이어를 보호하려 했다고 밝힌다. Alex는 문제의 규칙들이 문서대로 구현되었다고 말한다. 개인이 직무를 수행하는 행위들이 한데 모여 부조리한 제도가 된다.

최종 `Organization Master Consolidation`에서 일부 계열사의 최상위 지배력 경로는 `Horizon Holdings → Horizon Community Trust → Horizon Foundation`으로 수렴한다. **재단은 단순한 CSR 기관이 아니라 기업 의사결정을 지배하는 폐쇄적 네트워크의 중심**이었다.

같은 매핑 안에서 플레이어의 고용주 `Northstar Quality Services` 역시 Horizon 영향권으로 연결된다. 따라서 다양한 계열 시스템의 QA 계약, 고객사의 Defect Workflow 개입, 예외 처리 권한과 조직 내부의 침묵 압력이 새로운 의미를 갖게 된다.

## 결말 — Everything is working as intended

ONE HORIZON 최종 Release 검증 화면에는 `Identity / Payroll / Travel / Procurement / Medical / Organization: PASS`, `Blocking Defects: 0`, `SYSTEM STATUS: NORMAL`이 떠 있다. 일반적 기능 버그는 해결되었다. 그러나 Foundation 특혜, 인사/주거 통제, 일부 계정 접근 제한처럼 사람을 억압하는 정책은 **정상적인 Business Rule**로 계속 남는다.

최종 연출:

> VALIDATION COMPLETE  
> EVERYTHING IS WORKING AS INTENDED.  
> **NOTHING WRONG**

이후 내부 에스컬레이션·증거 보존·외부 제보·릴리스 승인 등 엔딩 분기를 넣을 여지는 있지만 **아직 확정되지 않았다**.

## 플레이어가 계속 조사하는 진짜 동기

- 1막: 티켓을 닫기 위해 재현한다.
- 2막: 티켓이 서로 충돌하므로 공통 Root Cause를 찾는다.
- 3막: 개발자에게 잘못된 원인 분류를 지적받아 Source/Target 책임을 가른다.
- 4막: 자신의 Cross-System Defect가 조직에 의해 예외 처리되지만, **명백한 데이터 정합성 리스크에 대한 처리 근거**가 불충분하다. 인물의 사망이 드러나면서 개인적·직업적 책임감을 느낀다.
- 5막: 관련 Ticket을 계속 받는 것은 Integration Regression 전문성을 인정받았기 때문이며, 다른 회사 시스템을 임의로 열지 않는다.
- 6막: 마감 Release QA에서 관계/권한/조직 데이터를 검증한다. 개인정보나 의료 원장을 무단 수집하지 않고 공식 품질·보안·준법 채널로 이관할 수 있는 증거의 범위와 한계를 고민한다.

## 앞선 감사/공권력이 전체 사건을 파악하지 못한 이유

- HR·Triply·보험·구매가 **서로 다른 Legacy ID**로 데이터를 관리했고 Cross-System 연결은 제한적이었다.
- 외부 재무감사는 중요성·표본·통제 범위가, 내부감사는 부서별 과제와 예외 승인 프로세스가 달랐다. 일부 경고/케이스가 있었으나 **증거가 부족하거나 범위상 종결**되었고, 일부 관리자도 의도적으로 억제했다.
- 경찰·소방·안전 조사기관은 실제 사고와 Daniel의 사망을 조사했다. 당시 조사에서 **재단 거래/고용상태 소급수정/다른 계열 프로그램의 연계**까지 드러나지 않았다. 해당 연결이 나중에 발견된다고 해서 곧바로 경찰의 과거 결론이 고의 은폐로 판명되는 것은 아니다.
- QA가 각 기록을 모두 볼 수 있었던 것은 **부여된 테스트 범위의 Source/Target 비교와 새 Global Identity Matching** 때문이다. 유출된 비마스킹 자료는 그 자체로 감사/보안 이슈로 다뤄야 한다.

## 화면과 장르 감정선

`SaaS 업무의 안도감 → 반복되는 날짜와 ID의 불편함 → 기록의 불일치 → 사람의 죽음 → 고의적 비즈니스 룰 → 통합된 권력 구조 → NORMAL이라는 말의 섬뜩함`

시스템·사진·대화와 제한된 보고서만으로 전달한다. 초자연·AI 모의세계·점프스케어는 사용하지 않는다.
