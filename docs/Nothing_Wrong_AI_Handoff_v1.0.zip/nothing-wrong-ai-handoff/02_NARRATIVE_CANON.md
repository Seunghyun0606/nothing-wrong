# NOTHING WRONG — Narrative Canon / Continuity Bible

## 1. Canon Levels

- **FIXED**: 사용자와 기존 기획에서 합의된 줄거리 사실. 임의 변경 금지.
- **PROPOSED**: 개발·테스트 편의를 위해 본 문서에서 구체화한 설정. 기획 확인 후 FIXED 승격.
- **UNKNOWN**: 작품 세계에서 아직 밝혀지지 않거나 의도적으로 결론을 열어 둔 사안. AI가 사실로 확정 금지.

## 2. 인물

| Entity ID | 이름 / 직책 | 플레이어가 처음 아는 정보 | 후반 사실 또는 역할 | 상태 |
|---|---|---|---|---|
| `P-PLAYER` | 플레이어 / Northstar Integration QA | 외주 QA 실무자 | 사실의 연결을 보는 사람, 무제한 접근 불가 | FIXED |
| `P-MINA` | Mina Seo / QA Lead | 엄격하지만 유능한 선임 | 이전 QA 철수 사례를 알고 과잉 탐색을 말림. 전말은 모름 | FIXED |
| `P-ALEX` | Alex Han / Integration Developer | Source를 신뢰하는 개발자 | 숨은 Community Rule이 Requirement로 승인됐다는 사실을 앎. 범죄 확정 인지 아님 | FIXED |
| `P-GRACE` | Grace Yoon / Horizon Program Manager | 고객사 담당 PM | Historical Exception 승인/종결에 관여. 고의 범죄 인지 범위는 미정 | FIXED / UNKNOWN |
| `P-DANIEL` | Daniel Park / Internal Control Analyst | 이전 회사 직원 `E-18419` | Foundation 관련 거래 조사 중 Horizon Ridge 사고에서 사망 | FIXED |
| `P-SAMUEL` | Samuel Kwon / Horizon Foundation 이사 | 사진 속 참석자, 재단 간부 | 폐쇄적 조직의 핵심 인물; 구체적 범죄 직접 지휘 여부는 미정 | FIXED / UNKNOWN |
| `P-SECURITY` | Foundation 보안책임자 | 사건 당일 사진·동선의 단서 | 사건 당일 동선의 관계자, 이름/유죄 미정 | PROPOSED |

**Daniel 키**: Legacy PeopleCore `E-18419`, Triply `T-55291`, CareBridge `P-88114`, PayFlow/Insurance 참조 `B-44210`, Global Person `P-004217`. `P-DANIEL`은 콘텐츠 저작용 ID이며 `P-004217`은 게임 내 Global Person ID다. 이 둘을 혼동하지 말 것.

## 3. 조직·장소·사건

| 내부 ID | 표현 | 설명 / 비고 |
|---|---|---|
| `O-HORIZON` | Horizon Group | 계열사 통합 프로젝트 고객 |
| `O-HOLDINGS` | Horizon Holdings | 공식 상위 지주사 |
| `O-COMMUNITY-TRUST` | Horizon Community Trust | 재단 관계자의 지배권 연결 구조(법적 형태 미정) |
| `O-FOUNDATION` | Horizon Foundation | 대외 CSR/복지 조직; 실제 폐쇄적 권력 네트워크의 중심 |
| `O-NORTHSTAR` | Northstar Quality Services | 표면상 독립 외주 QA, 실제 Horizon 영향권 |
| `O-BF-CONSULTING` | Bright Future Consulting / BF Consulting | 벤더 유사성 대상. 완전 동일 법인 여부는 검증 대상 |
| `O-NEW-PATH` | New Path Logistics | 커뮤니티 파트너 네트워크 |
| `O-HORIZON-LIVING` | Horizon Living | 커뮤니티 파트너 네트워크 |
| `LOC-RIDGE` | Horizon Ridge (`HRDG-01`) | 리더십·웰니스 연수 시설, 10월 17일 사고 발생 |
| `LOC-WELL-ANNEX` | Foundation Wellness Annex (`HF-WELL-03`) | 관리 의료재고 목적지 |
| `EV-OCT17` | Horizon Ridge Incident | 10월 17일, 사망 1명·부상 여러 명, 당국 조사 실시 |
| `EV-AWARD-2021` | Leadership Awards 2021 | 인물 관계 복선 사진 |
| `PRJ-ONE-HORIZON` | ONE HORIZON | Global Entity/Identity/Vendor Consolidation |

### 지배 관계 유의

최종 Narrative Reveal은 **재단 핵심 세력이 Trust/이사회 등으로 Horizon 그룹의 실질 지배력을 행사한다**는 것. 공개 사이트에 재단 단독 소유지분 100%가 반드시 등장할 필요는 없고 실제 법제도와 충돌하는 복잡한 소유 설명도 피한다. 게임은 **가상 법체계** 혹은 법률 자문을 통해 구조를 최종 확정해야 한다.

## 4. 시간축 / 사건 연도 가안

> 기존 원문에서 `October 17`은 날짜만 확정. 아래 `2021`은 Migration이 2022–2024에 걸쳤다는 이전 설정과 맞추기 위한 **PROPOSED YEAR**이다. 날짜를 바꾸면 모든 Ticket/사진·사건 메타데이터를 함께 바꿀 것.

| 시간 | 사건 | 증거 및 정확도 |
|---|---|---|
| 2019 | Foundation Gala, Samuel·Grace·Daniel 동일 행사 사진 | 장소 동석만 증명 |
| 2021 (사고 이전) | Leadership Awards 사진 | 시점은 촬영/게시 구분해야 함 |
| 2021-10-12 | Daniel의 `Irregular Vendor and Foundation Transactions` 케이스 생성 | Archive metadata |
| **2021-10-16** | PeopleCore상 Daniel 퇴사 효력일 | 실제 사전 퇴사 여부 불분명, 소급 변경 의혹 |
| **2021-10-17** | Horizon Ridge 행사, 대략 38명 이동, 공식 사고와 Daniel 사망 | 사망 사실 FIXED / 구체 시각 가안 |
| 2021-10-17 22:48 | Daniel 배지 Building B 출입 | Timeline QA 샘플 |
| 2021-10-17 23:06 | 긴급사고 발생 | Timeline QA 샘플 |
| 2021-10-17 23:11 | 의료 이벤트 생성 | Timeline QA 샘플 |
| 2021-10-17 23:18 | Foundation 차량 출차 | Timeline QA 샘플 |
| 2021-10-18 00:14 | 병원이송 | Timeline QA 샘플; 실제 사망 시간으로 단정 금지 |
| 2021-10-18 | Daniel 내부통제 케이스 종료; 사후 정정 시작 | 종료자/지시자 미정 |
| 2021-10-18~24 | HR·출장·재무·의료 기록의 개별 Correction | 일부만 의도적 조작 가능 |
| 2022 / 2023 / 2024 | PeopleCore / PayFlow / Triply 각각 다른 환경/시점의 Migration | 같은 단일 Batch 가설 배제용 |
| 현재 캠페인 | ONE HORIZON 최종 통합 QA | 세부 시작일 미정 |

**중요**: 과거 Migration(2022~2024)과 현 프로젝트의 통합 시험(2026 가정)은 **서로 다른 계층**이다. 2022/23/24에는 제품별 레거시 이전, 현재에는 Cross-system Global Identity 통합을 진행한다. 한 번의 Migration을 네 번 다른 날짜로 표현하지 말 것.

## 5. '무엇이 사실인가' 구분

| 주제 | 플레이어가 확인하는 자료 | 확인 가능한 사실 | 아직 단정 불가 |
|---|---|---|---|
| October 17 | Travel·HR·PO·보험/안전 요약 | 시설 사고와 Daniel 사망이 공식 기록됨 | 사건 전 과정/고의 방화 |
| Daniel | Global ID, HR termination, 보험 코드 | 데이터상 퇴사일과 사망사건이 서로 충돌 | 사고사가 아닌 타살 확정 |
| Vendor | 공통 주소군/계좌군, Daniel REJECT 기록 | 업체 관계가 의심되고 거래 검토가 있었다 | 모든 업체가 동일 법인/범죄단체 |
| Foundation | 관리자 룰/행사 사진/Ownership | 재단 네트워크가 인사와 구매 결정에 깊이 개입 | 모든 회원이 조직적 범죄 공모 |
| Medical | 재고 원장, 외부 Transfer | 일부 재고가 정상 환자 사용으로 설명되지 않음 | 실제 불법 마약 유통의 전체 경로 |
| Labor | HR/SSO/출장/사진 불일치 | 일부 참가자 계정 접근·이동 정보가 비정상 | 강제 노동/인신매매의 모든 피해·가해 사실 |
| Grace | 예외 승인, 사진, 사건 당일 접점 | 기록 종결 권한/재단 인적 교류 | 살해 명령 또는 전말 인지 |
| Mina | 이전 QA 철수 경고, Review | 억제적 행동과 보호 동기가 공존 | 범죄 공범 여부 확정 |

## 6. 감사·수사·권한 개연성

- **외부 감사**: 모든 시스템을 포괄적으로 전수 조사하는 기관이 아님. 회계감사 중요성과 과업 범위가 다르며, 인명 관련 사건 조사와 직접 동일시하지 않는다.
- **내부 감사/컴플라이언스**: 일부 지적 이력·종결 사유가 존재해야 한다. '한 번도 발견 못 했다'라고 쓰지 않는다. 특정 이슈는 충분한 근거 부족, 범위 제한, 예외 승인 등으로 닫혔다.
- **수사기관**: 당시 시설 안전사고와 사망을 확인/조사했다. 모든 고용/벤더/종교 네트워크 관련 관계를 확인하지 못했을 수 있다. 새로운 증거는 재조사 가능성을 만들지만 반드시 최초 수사가 부실했다는 뜻은 아니다.
- **외주 QA 권한**: 기본 읽기전용 + 제한된 테스트 계정/스냅샷 + 필요한 메타데이터. 운영 ERP 전수 조회, 실제 의료 원장 열람, 인사정보 무차별 검색은 **금지**. 모든 민감 정보가 QA 데이터로 드러나는 장면은 테스트셋 구성, 마스킹 누락, 승인된 현안 조사 등 반드시 정당한 경로를 설명한다.
- **행위의 동기**: Ticket 해결을 위한 Source/Target 검증, 고객에게 승인받은 예외 사유 확인, 릴리스 데이터 품질·개인정보 리스크 보고 등으로 제한. QA가 사설 수사를 자처하거나 위법한 유출을 수행하지 않는다.

## 7. 절대적 서사 가드레일

1. 사진의 **동석 = 공모**가 아니다. 이미지의 EXIF 시간/위치는 파일 변경·시간대 오류 가능성을 검증해야 한다.
2. `No Bug`는 QA 관점의 기술적 판단일 뿐, 회사 정책의 적법성·정당성의 보증이 아니다.
3. `Known Issue`나 `Accepted Risk`는 QA 결과와 구분해, 누가 언제 어떤 범위에서 수락했는지 Audit Trail이 있어야 한다.
4. `DB-01`은 **복리후생/보험 정산 코드**로 사용한다. 응급 처치 코드가 아니다. CareBridge에서 노출 시 인터페이스의 `Benefit Settlement` 구획에 나타나야 한다.
5. 사망 1명/부상 여러 명이 공식 사실이라면, `Major Incidents: 0`은 별도의 통계 범위/분류/중복 제거 규칙 탓에 잘못됐거나 제외되어야 한다. **전체 공적 사고 기록이 0**이라고 표현하지 않는다.
6. `퇴사 후 급여 4개월`에는 미지급 임금/유족 보상/정산/수정 지연이라는 합법적 설명도 가능하다. 분석 없이 바로 범죄라고 규정하지 않는다.
7. 국제이주·인신매매 정황에서는 피해자를 범죄 도구나 충격 소재로만 소비하지 않도록 신원과 자율성 문제를 구체적으로 다루며, 불필요한 폭력/성적 착취 묘사는 하지 않는다.
8. 약물의 제조·밀매·통제 실행에 대한 실용적 지침은 스토리 콘텐츠로 만들지 않는다. 플레이어는 **비용/수량/승인/계정 로그의 모순**을 다룬다.

## 8. 진실의 역설

- **진짜 소프트웨어 버그**: 이미지 Crop, 숫자 표시 누락, Mapping/Timezone/Permission 구현 오류.
- **데이터 무결성 문제**: 상이한 출처의 정정 이력, 사망과 퇴사의 불일치, 사고 참조 누락.
- **정상적으로 구현된 제도적 문제**: Community Alignment와 승진, Community Partner Override, 관리자 통제 계정, 재단을 향한 우대 정책.

엔딩의 메시지 `Everything is working as intended`는 마지막 범주의 시스템적 모순을 강조한다.
