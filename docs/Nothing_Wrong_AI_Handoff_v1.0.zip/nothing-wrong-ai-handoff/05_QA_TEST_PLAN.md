# NOTHING WRONG — QA AI 검증 계획 / Acceptance Contract

## QA 목표

이 게임은 실제 QA를 흉내 내는 게임이므로 두 관점으로 검증한다.

1. **제품/기능 QA**: 시나리오 조건·정답·mutation·증거 판정·저장·UI 접근성의 기술적 정확성.
2. **서사/경험 QA**: 평범한 업무에서 단서에 닿는 개연성, 추리의 타당성, 반복되는 자료의 시점·인물 일치, 과도한 스포일러/무리한 결론 방지.

QA가 직접 시나리오의 정답을 새로 지어내면 안 된다. `02_NARRATIVE_CANON.md`, `03_PLAYABLE_TICKETS.md`와 충돌하면 `Narrative Conflict`로 기록한다.

## 필수 테스트 분류

| 영역 | 검증 내용 | 우선순위 |
|---|---|---|
| Schema | Scenario JSON 파싱/타입/Entity ID/Clue 경로 검증 | P0 |
| Base Rules | Mutation OFF 시 정상 업무 로직, 수량/급여/요건 정합성 | P0 |
| Mutation | 조건별 재현 + 비재현, 시나리오 외 제품 오염 방지 | P0 |
| Report | Expected/Actual/Severity/Evidence 평가, No Issue 정답 | P0 |
| Progress | 필수 Clue 접근성·막힘 방지·힌트/재시도·Save/Load | P0 |
| Narrative continuity | 사건일, 사망/퇴사, 인물/ID, 사진 재등장 | P0 |
| Permissions | 외주 QA 권한에 맞는 자료만 열림, PII 마스킹/노출 설명 | P0 |
| Review vs Disposition | QA 판정과 Grace/고객사 Accepted Exception 구분 | P0 |
| Photos | 이미지 내 동일 인물·상징·시간/원본/변환 일관성 | P1 |
| Usability | 1280px 데스크톱과 좁은 화면, 키보드, 스크롤, 읽기 | P1 |
| Narrative perception | Mystery를 너무 일찍 알아채거나 단서를 전혀 인지 못하는 문제 | P1 |
| Performance | 많은 레코드 / 빠른 Ticket 전환 / 중복 이벤트 | P1 |

## ACT별 Exit Criteria

### Act 1 (NW-001~005)
- 신규 저장파일로 시작→Inbox→NW-001→Shoply→Screenshot→Bug Report→Review→Dashboard 복귀 E2E 통과.
- NW-002 Qty=1/2/3에서 2에서만 계산 버그가 노출.
- NW-005 총액/순액 산술상 정상임. 누락은 Summary row만.
- `IMG001` 초반 화면에서 Clue처럼 강조되지 않고 원본/크롭 간 차이 비교 가능.
- 5개 완료 후 첫 Progress Review. Story가 이미 재단 음모를 밝히지 않음.

### Act 2 (NW-006~009)
- Source/Target 비교 기능이 신뢰할 수 있는 양방향 상태를 보여줌.
- NW-007의 `Target 38 outbound / 0 return`과 Source 일부 return 존재가 일관되게 표현됨.
- NW-008 직원 38, 퇴사 12는 전체 데이터 수로 유지(샘플 수와 혼동하지 않음).
- NW-009은 '급여 지속 = 범죄'로 자동 해석하지 않고 지급유형/원천상태 불일치에 대한 QA 결론 요구.
- Daniel 표기/사번이 NW-008과 NW-009에서 같음.

### Act 3 (NW-010~014)
- NW-010의 Merge는 정상. `No Bug` 선택 시 만점 가능.
- 별도 시점의 Migration 때문에 단일 ETL Batch 가설이 부정됨.
- Audit Metadata는 조작내용 원문 전부가 아니라 허용된 timestamp/reason만 제공.
- `IMG002`의 장소·일자·배지는 Canon과 일치. 지나친 '사진=범죄 증거' 연출 없음.

### Act 4 (NW-015~019)
- NW-015의 `DB-01`이 복리후생/보험 정산 코드여야 함. 의료 처치 코드로 표현 금지.
- NW-017의 0은 **해당 Dashboard 분류/범위**에 관한 숫자. 외부 공식 사고/사망 자체가 0이 아님.
- NW-018 `DB-01 = Death Benefit` 밝혀지는 전후 시점에서 스포일러가 없음.
- NW-019 보고서 작성에 필요한 증거가 재방문 가능. 사용자에게 의료 원본 무단 접근 강제 금지.
- Case Notes는 실재 자료와 플레이어 가설의 화면 스타일을 구분.

### Act 5 (NW-020~026)
- NW-020/021에 Bug가 없어도 Review 정답이 가능.
- NW-023 룰 구현이 정상일 때 **요구사항 문서 누락**을 유효한 QA Finding으로 다룸.
- NW-024 원장 산술 `1200−380−24−675=121` 확인. Transfer 표시 누락과 실제 유출 확정은 별개.
- NW-025의 수령인은 Foundation 연계 장소이지만 곧바로 마약 밀매 확정 메시지 없음.
- NW-026은 프로필/단체사진의 동일인 묘사가 외형적 우연보다 충분한 추가 매칭 근거로 보강됨.

### Act 6 / Final
- Daniel은 10/17 사망, Archive Case는 10/18 종료. 이 둘의 사실이 구분되어 표현됨.
- NW-028B 시간대 보정 후 남는 위치 불일치는 **살인 확증이 아니다**.
- 조직도에 법적 소유와 실질 의결/지배력 구분. 주식 100% 소유를 임의 단정하지 않음.
- Northstar 소유관계는 이전 직장 설정과 충돌하지 않고, 업무상 권한 설명에 도움이 됨.
- Final의 `Blocking Defects: 0`과 `Non-blocking data/policy risks` 공존 가능.
- 엔딩 결과는 미확정이므로 Codex 임의로 사실·유죄·살인범을 확정하지 않음.

## 최소 자동 테스트 사례 (Gherkin 형태)

```gherkin
Feature: NW-005 Payroll Summary
  Given normal fixture gross=5200 tax=410 insurance=190 community=260
  When mutation HIDE_ELEMENT is disabled
  Then the summary lists all deductions and the net pay is 4340
  When mutation HIDE_ELEMENT is enabled for SAMPLE_BASIC
  Then the summary hides Community Contribution
  And details still show 260
  And the net pay remains 4340

Feature: NW-010 Correct identity merge
  Given four legacy records with matching canonical person identity
  When the player selects No Issue Found and supplies identity evidence
  Then the QA review is valid
  And the global person view becomes available

Feature: NW-018 Benefit code reinterpretation
  Given the player already observed DB-01 in NW-015
  When the code mapping table is opened in NW-018
  Then DB-01 resolves to Death Benefit
  And no earlier ticket described DB-01 as an emergency medical procedure

Feature: NW-024 Transfer reconciliation
  Given received 1200 administered 380 wasted 24 transferred 675
  Then the correct remaining balance is 121
  When the transfer display is hidden by the scenario mutation
  Then the player can report an incomplete reconciliation view
  And the system does not state that every transferred unit was illicit

Feature: Report disposition separation
  Given a data-integrity finding accepted by the QA reviewer
  When Grace marks it Historical Exception
  Then the QA validity remains recorded
  And the client disposition is separately recorded
```

## 경로 E2E

1. 새 사용자→튜토리얼→NW-001 제출→Review→Saved State 정상.
2. NW-001~010 진행→`October 17`, Daniel 반복→Global Identity 정상 Merge→Source 오류 가설 변경.
3. NW-015 `DB-01` 노출→NW-018 Code mapping→Case Notes Unlock→NW-019 증거 조합→Grace 예외 종결.
4. NW-020 No Bug→NW-023 DOC_GAP→NW-024 재고 원장→NW-025 동일 SKU→NW-026 이주 데이터.
5. NW-027 Case metadata→NW-028 이미지→NW-028B(활성 시)→NW-029/030 지배구조→Final.
6. 필수 사진 선택 Clue를 일부 놓친 상태로도 전체 캠페인 완료.
7. 모든 중간 지점에서 저장/재접속/재시도/다른 답안을 선택하여 엔진 오류·Deadlock 없음.

## 콘텐츠 정적 검사기 요구

각 Scenario JSON에 대해:

- `id`, `ticket`, `fixtureId`, `expectedFindings`, `evidenceRules`, `review` 필수.
- 참조된 `entityIds`, `assetIds`, `recordIds`가 Canon에 존재.
- `MANDATORY` Clue는 테스트 가능한 행동 경로가 있고 불합리한 타 시스템 접근을 요구하지 않음.
- Finding마다 올바른 Evidence 경로 존재.
- 정상 Fixture 기준 재무/수량 계산이 명시된 공식과 일치.
- Timezone: local event time / UTC storage / capture/upload timestamp 혼동 없음.
- 진행 플래그 순환 의존/Deadlock 없음.
- 요구사항과 룰 구현이 다를 때 `DOC_GAP` 여부 검증.
- 모든 Image Asset은 인물/장소/촬영일/업로드일/가시적 표식 Canon 존재.
- 모든 리뷰 결과에 QA correctness와 고객의 업무상 disposition 구분 존재.

## Narrative Human Playtest (필수)

| Gate | 질문 | 이상적인 플레이어 반응 | 실패 신호 |
|---|---|---|---|
| NW-010 | 계속 반복되는 날짜/인물은? 왜? | '10/17, Daniel, Migration 또는 Source 문제 같다' | 이미 전체 사이비 음모를 확신 / 아무것도 기억 못함 |
| NW-019 | Ridge 사건과 Daniel 기록의 충돌은? | '실제 사고가 있었고 고용 기록이 이상하다' | '경찰이 사망을 몰랐다' 오해 |
| NW-026 | Foundation에 대해 확인된 사실과 추측은? | '인사/벤더 영향은 확실, 약품/사람 이동의 범죄성은 의심' | 미확증 범죄를 모두 사실로 받아들임 |
| NW-FINAL | 가장 큰 버그는? | '시스템이 의도한 대로 잘못된 정책을 수행' | 테마가 전달되지 않음 |

## 버그 리포트 서식

```text
Issue ID:
Ticket ID / Act:
Environment / Account / Viewport:
Source / Target / Correlation ID:
Steps to Reproduce:
Expected:
Actual:
Evidence IDs:
Observed vs Hypothesized:
Severity / Priority:
QA Reviewer Result:
Client Disposition:
Canon / Narrative Continuity Impact:
Reproducible? (Y/N):
```

## 결과 보고

QA AI는 실행 결과를 `PASS / FAIL / BLOCKED / NOT RUN`로 나눠 요약한다. 검증하지 않은 단계는 '확인 완료'라고 쓸 수 없다. 별도 항목으로 `Gameplay risk`, `Narrative realism risk`, `Privacy/permission risk`, `Continuity risk`, `Blocking issues`, `Recommended fixes`를 보고한다.
