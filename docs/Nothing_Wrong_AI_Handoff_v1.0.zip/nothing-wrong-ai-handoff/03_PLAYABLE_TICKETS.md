# NOTHING WRONG — 플레이 가능 캠페인 Ticket 명세

## 0. 공통 콘텐츠 규칙

각 Ticket은 `업무 의뢰 → 정상 동작 확인 → 재현 → 증거 → QA 결론 → Review`로 완결되어야 한다. 각 카드에는 정상 UI/데이터가 버그보다 더 많아야 하며, **스토리 단서와 QA 정답은 별개 필드**로 유지한다.

**Ticket Outcome**: `BUG`(기술 버그), `NO_BUG`(정상), `DOC_GAP`(요구사항 누락), `DATA_INTEGRITY`(상태·마스터 충돌), `INCONCLUSIVE`(확증 부족). `WORKING_AS_DESIGNED`는 `NO_BUG`의 리뷰 사유지 기업 정책의 면죄부가 아니다.

**Evidence**: 정답 핵심 속성/조건을 담은 상태 캡처. 단순 해당 화면 스크린샷 1장만으로 항상 만점이 되지 않는다.

**공통 완료 조건**: (a) 관련 시나리오 실행, (b) 올바른 분류 선택, (c) 해당 Outcome에 필요한 증거/No Issue 판단, (d) 리뷰 반환, (e) NarrativeClue 발견 상태 갱신. 틀린 답변도 다시 시도할 수 있게 하고 메인 서사 진행은 막지 않는다.

## ACT 1 — ROUTINE (NW-001~005)

| ID / 시스템 | QA 의뢰와 실제 조작 | 정답 / 재현 조건 | 증거 / 자연스럽게 보이는 Clue | 완료 후 경험 |
|---|---|---|---|---|
| **NW-001 / Shoply** | Checkout CTA Regression. 기본 계정으로 상품→카트→Checkout 열기 | `BUG`, 데스크톱에서 Primary 버튼이 Secondary 스타일. 정상 결제 동작은 유지 | Checkout 화면 캡처; Narrative 없음 | Report/Evidence/Severity 학습 |
| **NW-002 / Shoply** | Cart 수량 1→2→3 변화, 단가 $30과 Subtotal 비교 | `BUG`, Qty=2에서 $50, 기대 $60. 다른 수량은 정상 | Qty=2와 가격/합계 동시 표시; `C001` 테스트 회사 `Horizon Community Services` | 숫자 검증 |
| **NW-003 / PeopleCore→Horizon ID→Shoply** | 프로필 Tier 소스와 쇼핑 계정 동기화 비교 | `BUG`, Source `STANDARD`, Target `PREMIUM` | 두 상태 나란히 캡처; `C002 Community Tier` | 간단한 Source/Target 사고 도입 |
| **NW-004 / CMS→Portal** | `IMG001` 행사 사진 원본/이관 썸네일 비교 | `BUG`, 오른쪽 인물 얼굴이 Crop | 원본/변환 비교, 넓은 사진 안의 Grace·Samuel·Daniel(현재 미표기) | 이미지 QA / 인물 관계 복선 |
| **NW-005 / PeopleCore/PayFlow View** | 급여 요약 합계 검증, Details 펼치기 | `BUG`는 계산이 아니라 **공제 항목 미표시**. 5200−410−190−260=4340 맞음 | Summary와 Detail 비교; `C003 Community Contribution` | 조건/원인 분류, Act 1 Performance Review |

## ACT 2 — OCTOBER 17 (NW-006~009)

**새 기능**: Source/Target Compare, 이관 기록/필터. 사용자에게 '공통 Migration'을 자연스럽게 의심하게 만들되 확답을 주지 않는다.

| ID / 시스템 | QA 의뢰와 조작 | 정답 / 재현 조건 | 증거 / Story Clue | 서사 역할 |
|---|---|---|---|---|
| **NW-006 / Shoply Legacy→Next** | 15개 역사 주문 Source/Target 비교, 날짜 필터 | `BUG`: 10월 17일 원본 `COMPLETED` 일부가 Target `CANCELLED/ABSENT` | 17일 전후 정상 행 + 비정상 행, `C004` Oct 17 | 날짜 패턴 첫 등장 |
| **NW-007 / Triply** | Outbound/Return 매핑 검증, Legacy↔Next 비교 | `BUG`: 소스에 남은 일부 return segment가 Target에서 누락. **Target 38 outbound / linked return 0**; Source에도 일부 참가자의 귀환 정보는 원래 없음 | Source 정상 segment 및 Target 빈 연결; `C005 HRDG-01 / 38 people` | 동일 날짜/인원 수 반복. 0은 Target 표시값임 |
| **NW-008 / PeopleCore** | Training Leave History Source/Target 정합성 | `BUG`: 과거 유효 레코드 일부가 Target History에서 누락 | Before/After 상태 및 `C006 E-18419 Daniel`, 38 leave / 12 resign records | Daniel 첫 등장 |
| **NW-009 / PeopleCore→PayFlow** | 퇴사 이벤트가 이후 지급/정산에 반영되는지 검증 | `DATA_INTEGRITY`: Daniel 10/16 퇴사·그 후 거래의 성격/상태 불일치. **퇴사 뒤 지급만으로 오류 확정 불가**, 지급 유형을 비교해야 함 | 양쪽 기록과 transaction type. `C007 Daniel 반복` | 제출 후 고객사 `KNOWN ISSUE` 처리(기술 결과와 업무상 처분 분리) |

**ACT 2 체크포인트**: 플레이어에게 임의 추적 대상 검색을 제공하지 않고, `원본 스냅샷 문제인가?`라는 QA 가설을 제안할 수 있다.

## ACT 3 — SOURCE DATA (NW-010~014)

**새 기능**: Global Entity View, Trace, 수정자/시각/사유 Code를 담은 **허용된 Audit Metadata(원문 기록 열람 아님)**.

| ID / 시스템 | QA 의뢰와 조작 | 정답 / 재현 조건 | 증거 / Story Clue | 서사 역할 |
|---|---|---|---|---|
| **NW-010 / Horizon ID** | Person matching 후보 4개의 키 값 비교 및 Merge 여부 선택 | `NO_BUG`: E-18419/T-55291/P-88114/B-44210는 동일 인물 P-004217 | 이름·해시·부분 이메일·원본 Ref가 같은 조건 | 다른 시스템의 Daniel이 동일 인물임을 확정 |
| **NW-011 / Integration Tool** | 이전 3개 Migration의 Root Cause 분류. 배치 시각 비교 | `NO_BUG` on global orchestrator; `SOURCE_DATA` 이슈로 전달. Migrated 2022/23/24 | Migration history; Alex의 기술적 반박 | 공통 Batch 가설 반증 |
| **NW-012 / QA Audit Metadata** | Source Snapshot의 `modifiedAt`/correction marker 불일치 확인 | `BUG`는 수정 Timestamp Export 매핑; 원본 Correction은 실제 기록. 내용 자체의 범죄성은 미확정 | HR/TRV/FIN/MED 수정 계정·Oct18/19/21/24; `C009 DATA_CORRECTION` | 분산된 사후 정정 패턴 |
| **NW-013 / Triply** | Legacy `HRDG-01` 코드 Target 명칭 매핑 검증 | `BUG`: 일부 행에서 지명 blank | `Horizon Ridge – Leadership & Wellness Center`; `C010` | 장소에 이름 부여 |
| **NW-014 / CMS** | `IMG002` 행사 사진의 이관 Album Category 비교 | `BUG`: Expected `Leadership Program`, Target `Community Event` | 이미지 배경 배지/심벌·장소·날짜(메타데이터는 검증 필요) | Act1 사진과 상징 연결 가능 |

**ACT 3 체크포인트**: 첫 명확한 가설 변경은 **'이관이 오류를 만들었다' → '원본에 이미 충돌이 있었다'**이다. 범죄 확정이 아니다.

## ACT 4 — ZERO INCIDENT (NW-015~019)

**새 기능**: Historical Reference와 Case Notes. 시나리오 NW-018 완료 뒤 처음으로 의미 연결 화면을 활성화한다.

| ID / 시스템 | QA 의뢰와 조작 | 정답 / 재현 조건 | 증거 / Story Clue | 서사 역할 |
|---|---|---|---|---|
| **NW-015 / CareBridge Benefits→PayFlow** | 긴급 복리후생 정산금액과 이체액 비교 | `BUG`: Settlement summary 표현/매핑 불일치. `DB-01`은 별도 **benefits claim type**이며 아직 해설 숨김 | Claim line `P-004217`, date 17~18 Oct, code `DB-01` | Daniel 관련 혜택 코드 복선 |
| **NW-016 / Procura** | Emergency PO의 Destination mapping 검증 | `BUG`: 특정 PO의 장소 값 blank | 구매종류·시각·Ridge 목적지 | 사고 규모 의문 발생 |
| **NW-017 / Compliance Dashboard** | 월간 Incident 0 vs Orphan Reference 검증 | `DATA_INTEGRITY`: Dashboard 필터 계산 자체는 현재 정의에 맞지만 `INC-1017` 원본 참조 누락/분류 충돌 | `INC-1017/DUPLICATE`와 공식 통계의 **범위 차이** | '사고가 있었나?' 가설 진입 |
| **NW-018 / Insurance Mapping** | Legacy Benefit Code Description 쌍 중 스왑 찾기 | `BUG`: Code description swapped; `DB-01=Death Benefit` 원본 기준 확인 | 참조표 + NW-015의 코드 재해석 | Daniel 사망 Reveal / Case Notes Open |
| **NW-019 / Cross-System Defect** | Daniel의 HR·Travel·Benefit·Official Incident 요약 연결 후 Quality Issue 작성 | `DATA_INTEGRITY`, 위험도 HIGH/CRITICAL 제안 가능. 코드상 퇴사 자체는 승인 정정일 수 있어 **독립적으로 불법/오류 확정하지 않음** | HR exit Oct16 + 10/17 incident + benefit + approved correction metadata | Grace가 업무적으로 예외 종결, 플레이어에게 리뷰와 예외 승인권의 차이 인식 |

**ACT 4 공식 사건 문서**: `Horizon Ridge Facility Incident / Accidental / One fatality / Multiple injuries`. 이것은 수사기관의 존재를 없애는 반전이 아니라 **사건에 대한 기존 공적 인지**를 보여주는 자료다.

## ACT 5 — THE FOUNDATION (NW-020~026)

**새 기능**: Entity Relationship/Reference Catalog, 이미지 메타데이터 비교, 현재 사업 룰 조회(권한 내). `NO_BUG`의 비중을 높인다.

| ID / 시스템 | QA 의뢰와 조작 | 정답 / 재현 조건 | 증거 / Story Clue | 서사 역할 |
|---|---|---|---|---|
| **NW-020 / Procura** | 유사 벤더 Auto-Merge false positive 검사 | `NO_BUG`: 여러 alias/affiliate 기록의 매칭 근거가 허용 임계값에 맞음. **동일 법인이라고 단정 안 함** | 등록주소군·대리인·연락처, Daniel의 과거 `REJECTED` | Daniel의 업무와 재단 관련 벤더 연결 |
| **NW-021 / Procura Rules** | Preferred Vendor 5% vs 특정 Vendor 18% 할인 확인 | `NO_BUG / WORKING_AS_DESIGNED`: `COMMUNITY_PARTNER_OVERRIDE` 승인 룰 | 기본 룰과 예외 룰 비교 | 기술적 정상과 제도적 특혜 구분 |
| **NW-022 / Foundation Portal** | Tablet Gallery 깨짐 재현, 사진 확대/메타데이터 비교 | `BUG`: 반응형 이미지 레이아웃. `IMG003~005`는 서사 복선 | Samuel·Grace·Daniel 동석, 배지, 행사 시점 | 인물 관계 재해석(공모 확정 아님) |
| **NW-023 / PeopleCore** | 승진 조건 A 등급/근속 4년인데 탈락한 사례 테스트 | `DOC_GAP`: 실제 백엔드 추가 룰 `CommunityAlignment≥70` 존재. **무조건 INVALID가 아니라 문서 누락 이슈는 유효** | 공개 Requirement vs 승인 Ruleset | 'Working as Designed'의 첫 충격 |
| **NW-024 / CareBridge Inventory** | 입고 1200, 환자 사용 380, 폐기 24, 표기 잔량 121 검증 | `BUG`: 675 단위 **Transfer**가 잔액 계산/화면에서 누락. 원장 기준 `1200-380-24-675=121`은 맞음 | Hidden transfer `HF-WELL-03`, SKU-MD204 | 투약 기록 밖의 이동과 재고 UI 결함 구분 |
| **NW-025 / RouteOne** | `SKU-MD204` shipment의 recipient region 확인 | `BUG`: 우편/지역 코드 mapping | Destination `HF-WELL-03 → Foundation Wellness Annex`, restricted medical category | 약품의 최종 사용/불법성은 미확정 |
| **NW-026 / PeopleCore+Triply+ID+PayFlow** | 해외 배치 직원 위치·급여 법인·계정 동기화 테스트 | `BUG`는 Country/Payroll Entity Mapping. `ACTIVE / no login / no return / admin-controlled contact`는 별도 모니터링 정황 | `IMG006` 집단 사진 vs 프로필 인물, Opportunity Program | 신원 자율성 및 착취 정황 |

**ACT 5 체크포인트**: QA가 '이상한 데이터를 찾았다'에서 '유효한 정책이 사람을 해치는가?'라는 질문으로 이동한다. 의료·인신 관련 이슈는 무죄추정과 증거 수준을 유지한다.

## ACT 6 — DANIEL'S LAST CASE (NW-027~030)

**새 기능**: Archive Meta, Timeline Compare, Org Hierarchy. NPC 독백보다 플레이어가 자료로 관계를 직접 연결하게 한다.

| ID / 시스템 | QA 의뢰와 조작 | 정답 / 재현 조건 | 증거 / Story Clue | 서사 역할 |
|---|---|---|---|---|
| **NW-027 / Document Archive** | 테스트 권한으로 볼 수 있는 이전 케이스의 `Viewer` attachment preview 접근 검증 | `BUG`: 승인 대상의 문서/미리보기가 권한 Rule과 다르게 거부됨. **기밀 케이스 전체 원문 열람 불가** | Daniel의 Case 메타: created 10/12, closed 10/18 | 사망 후 케이스 종료 |
| **NW-028 / Document Image** | 사내 자료 이미지 Orientation/Thumbnail 오류 재현 | `BUG`: EXIF orientation 누락, 이미지 회전 | `IMG007` Daniel·Grace·Samuel·보안담당자, 사고 이전 metadata | 사고 전 인물 접점 |
| **NW-028B (옵션) / Access Timeline** | 여러 로그의 UTC↔현지시각 표시를 보정 | `BUG`: 일부 표기 Timezone offset. 보정 이후에도 위치 불일치 | 출입·의료·차량·이송 Timeline | 살인은 **가설 선택 가능, 정답 확정 불가** |
| **NW-029 / Organization Master** | 공개 Org Tree와 Source control hierarchy 값 비교 | `NO_BUG / DOC_GAP`: 상위 신탁 지배관계는 Source에 존재하지만 UI가 표시 범위를 제한 | Holdings→Community Trust→Foundation 지배력 연결 | Foundation 권력망 Reveal |
| **NW-030 / Organization Master** | Northstar vendor/customer record parent chain 유효성 확인 | `NO_BUG`: Northstar가 Horizon 영향권임을 매핑 데이터가 보여줌 | Northstar→Services Holdings→Trust→Foundation | 플레이어 회사와 네트워크 연결 |

## NW-FINAL — ONE HORIZON Release Validation

- **표면 업무**: Identity / Payroll / Travel / Procurement / Medical / Org 영역에 제한된 Coverage Budget을 배치하고 릴리스 위험을 평가.
- **플레이 선택**: 체크할 영역, `SHIP / HOLD`, 리스크 별도 코멘트, Evidence 보존/정식 이관 여부(엔딩 정책은 미확정).
- **기술 결과**: 주요 컴포넌트의 Regression은 PASS일 수 있지만, `DATA_INTEGRITY`, `DOC_GAP`, `POLICY/ETHICS_RISK`는 개별 기록으로 남는다. **0 blocking defect가 0 risk를 뜻하지 않음**.
- **최종 표시**: `VALIDATION COMPLETE / SYSTEM STATUS: NORMAL / Everything is working as intended.`

## 필수 서사 게이트

| 게이트 | 최소 획득 정보 | 실패/힌트 처리 |
|---|---|---|
| G1 날짜 패턴 | NW-006/007/008 중 2건 + 날짜 | 진행 차단 금지, Recent Tickets 참조 표시 |
| G2 Identity | NW-009 반복 인물 + NW-010 Global ID | ID Compare 튜토리얼 허용 |
| G3 Source Error | NW-011 Migration 별도 시점 + NW-012 수정 이력 | 잘못된 가설 선택 후 비교 재시도 |
| G4 Incident | Ridge 장소 + Emergency 기록 + Compliance 참조 | 공식 사고 설명 자료는 NW-019 Review 시 필수 제공 |
| G5 Daniel Death | Benefit `DB-01` + 보험 Codebook + HR 기록 | NW-018 이후 연결 안내(스포일러 제한) |
| G6 Foundation Network | Vendor cluster + special rule + Relationship evidence | 일부 이미지 선택 Clue 없어도 진행 |
| G7 Control | Org ownership/control + Northstar mapping | 법적/실질적 지배 차이 설명 |

## 스토리와 스코어 독립성

- 버그 찾기 점수와 미스터리 해석 점수는 분리.
- 틀린 Root Cause/Severity/가설은 적정 피드백을 주되 무조건 Game Over 금지.
- 사진을 놓친 플레이어에게 NW-022/028에서 재학습 기회를 준다.
- **No Issue Found**는 `NO_BUG`에 대해 완전한 정답이 될 수 있으며 `WORKING_AS_DESIGNED`가 드러내는 윤리적 불편함과 충돌하지 않는다.
