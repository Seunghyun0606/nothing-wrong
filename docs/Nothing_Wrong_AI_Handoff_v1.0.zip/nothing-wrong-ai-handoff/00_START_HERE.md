# NOTHING WRONG — AI Collaboration Handoff

- 문서 버전: `handoff-1.0` (2026-10-18)
- 프로젝트: **Nothing Wrong**
- 장르: Corporate Mystery / Integration QA Investigation Thriller
- 형식: Web desktop 우선, 선택지·QA 업무·이미지/데이터 비교 기반
- 캠페인 목표: 약 5–7시간, 메인 Ticket 30개 + 선택적 28B + Final Release
- 문서 목적: **기획 AI / 개발 AI / QA AI가 동일한 사실과 제약을 공유**하도록 하는 인수인계

> 본 문서 묶음은 사용자가 합의한 `Main Campaign Scenario v0.5`와 `Playable Campaign Content Specification v0.1`, 이어진 시놉시스 논의를 바탕으로 작성한 **제작용 통합본**이다. 코딩이나 Git 커밋/배포를 수행한 결과물이 아니다.

## 파일 안내

| 파일 | 목적 | 주 소비자 |
|---|---|---|
| `01_MASTER_SYNOPSIS.md` | 전체 스토리, 감정선, 6막, 결말, 추리의 인과 | 전원 |
| `02_NARRATIVE_CANON.md` | 인물·조직·사건·날짜·공식 사실과 미확정 가설 | 기획 / 개발 / QA |
| `03_PLAYABLE_TICKETS.md` | NW-001~030 + 선택 028B + FINAL 콘텐츠 매트릭스 | 기획 / 개발 / QA |
| `04_SCENARIO_ENGINE_CONTRACT.md` | 데이터 스키마, 예시 JSON, 증거·리뷰·진행 조건 | 개발 / QA |
| `05_QA_TEST_PLAN.md` | 콘텐츠 QA, 개연성 검증, E2E, 수용 기준 | QA / 개발 |
| `06_AGENT_PROMPTS.md` | 각 AI에게 복사해서 전달할 프롬프트 | 사용자 / 전원 |
| `07_IMAGE_ASSET_BIBLE.md` | 반복 등장하는 인물/사진·메타데이터 및 시각 단서 | 기획 / 아트 / QA |
| `08_OPEN_DECISIONS.md` | 기존 설계상 보완해야 할 가정·모순·결정 보류 항목 | 기획 / QA |
| `NOTHING_WRONG_ALL_IN_ONE.md` | 위 자료를 순서대로 병합한 단일 전달용 문서 | 단일 AI 세션 |

## 필수 원칙 — 어떤 역할도 변경 금지

1. **QA가 주 게임**이다. `Ticket → 요구사항 파악 → 재현 → Source/Target/Trace 비교 → Evidence → Report 또는 No Issue → Review`를 유지한다.
2. 플레이어는 Horizon의 내부감사 담당자도 경찰도 아니다. **Northstar 소속 외주 통합 QA**이며, 업무에 할당된 **SIT/UAT/QA 뷰와 비식별 이관 데이터**로만 검증한다.
3. 중요한 미스터리 정보는 **QA 검증에 필요한 화면/첨부/로그**로 자연스럽게 등장한다. 독립적인 ‘해킹/비밀 탐색’으로 정답을 찾게 만들지 않는다.
4. **버그가 아닌 정상적 비즈니스 룰**이 실제 범죄적 의도를 실행한다는 역설이 제목의 핵심이다. `WORKING AS DESIGNED`는 진실의 정당성을 뜻하지 않는다.
5. `October 17 → Horizon Ridge → Daniel Park → Foundation → Network → Northstar` 순으로 인지가 확장된다. 전말을 초반에 노출하지 않는다.
6. 사진은 얼굴·상징·공간·시간의 **관계 암시**로 사용한다. 사진 한 장만으로 범죄/공모/살인을 ‘확정’하면 안 된다.
7. 당시 **사망과 시설 사고는 공공기관이 인지하고 조사했다**. 숨겨진 것은 사망 자체가 아니라 고용 관계, 재단의 연결, 조직적 조작과 범죄 네트워크다.
8. 내부/외부 감사는 무능하거나 전원 공범이 아니다. 조사 범위, 분리된 ID, 불충분한 증거, 승인된 예외 처리와 일부 의도적 개입이 합쳐져 큰 그림을 놓쳤다.
9. Daniel의 **사망은 확정**, **고의 살해는 미확정**. 약품 및 강제 노동 관련 부분도 초기에는 정황 증거이며 범죄명을 자동 확정하지 않는다.
10. 스토리 필수 단서는 막힘 없이 재방문/대체 경로로 확보 가능. 선택적 사진 기억에 메인 진행을 종속시키지 않는다.

## 권장 작업 방식

- **기획 AI**: `01 → 02 → 03 → 07 → 08` 순서로 읽고 새로운 Ticket/대사/자산을 작성. 모든 추가 내용은 Canon과 Clue 의존 관계를 검증.
- **개발 AI**: `01 → 03 → 04 → 05` 순서로 읽고 **NW-001 1개 End-to-End**부터 개발. 이후 001~005, 006~010 순으로 수직 슬라이스 개발.
- **QA AI**: `01 → 02 → 03 → 04 → 05 → 08` 순서로 읽고 자동 테스트 + 서사 수동 평가를 구분.
- 변경이 필요한 경우 `08_OPEN_DECISIONS.md`에서 의사결정 기록 → Narrative Canon 갱신 → Ticket/Schema/QA 케이스 동기화 순서로 수정.

## 우선순위 / 충돌 해결

`02_NARRATIVE_CANON.md`(사실관계) → `01_MASTER_SYNOPSIS.md`(서사 의도) → `03_PLAYABLE_TICKETS.md`(콘텐츠) → `04_SCENARIO_ENGINE_CONTRACT.md`(구현 표준) → 개별 생성물.

아래는 **계획 단계의 가정**으로, 승인 전 법적/서사적 확정 사실처럼 표현하지 말 것:

- 사건 연도 `2021-10-17`은 **가안**. 2022~2024 Migration이 그 이후여야 한다는 연대기 정합성을 위한 제안이다.
- Foundation의 정확한 법률상 소유·지배구조, 소재 국가와 적용 법률은 **미정**이다. 문서의 `Community Trust → Foundation`은 지배력 관계를 묘사하는 픽션상의 작업 가정이다.
- 30개 Ticket/5–7시간은 **목표 분량**이지 검증된 플레이타임이 아니다.

## 완료 보고 형식

각 역할 AI는 답변에 `변경 파일 / 작업 내용 / 관련 Ticket·Clue ID / 테스트 증거 / 기존 Canon과 차이 / 남은 이슈 / 다음 우선순위`를 반드시 포함한다.
